import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../models/building.dart';
import '../models/unit.dart';
import '../services/unit_service.dart';

class UnitScreen extends StatefulWidget {
  final Building building;

  const UnitScreen({
    super.key,
    required this.building,
  });

  @override
  State<UnitScreen> createState() => _UnitScreenState();
}

class _UnitScreenState extends State<UnitScreen> {
final UnitService _service = UnitService();

Future<void> _showAddUnitDialog() async {
final unitController = TextEditingController();

final rentController = TextEditingController();

final depositController = TextEditingController();

final bedroomController = TextEditingController(text: "1");

final bathroomController = TextEditingController(text: "1");

String unitType = "Apartment";

bool furnished = false;

bool parking = false;

await showDialog(
context: context,
builder: (_) {
return StatefulBuilder(
builder: (context, setDialogState) {
return AlertDialog(
title: const Text("Add Unit"),
content: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [

TextField(
controller: unitController,
decoration: const InputDecoration(
labelText: "Unit Number",
),
),

const SizedBox(height: 15),

DropdownButtonFormField<String>(
value: unitType,
items: const [
DropdownMenuItem(
value: "Apartment",
child: Text("Apartment"),
),
DropdownMenuItem(
value: "Bedsitter",
child: Text("Bedsitter"),
),
DropdownMenuItem(
value: "Studio",
child: Text("Studio"),
),
DropdownMenuItem(
value: "Office",
child: Text("Office"),
),
DropdownMenuItem(
value: "Shop",
child: Text("Shop"),
),
],
onChanged: (value) {
setDialogState(() {
unitType = value!;
});
},
),

const SizedBox(height: 15),

TextField(
controller: bedroomController,
keyboardType: TextInputType.number,
decoration: const InputDecoration(
labelText: "Bedrooms",
),
),

const SizedBox(height: 15),

TextField(
controller: bathroomController,
keyboardType: TextInputType.number,
decoration: const InputDecoration(
labelText: "Bathrooms",
),
),

const SizedBox(height: 15),

TextField(
controller: rentController,
keyboardType: TextInputType.number,
decoration: const InputDecoration(
labelText: "Monthly Rent",
),
),

const SizedBox(height: 15),

TextField(
controller: depositController,
keyboardType: TextInputType.number,
decoration: const InputDecoration(
labelText: "Deposit",
),
),

const SizedBox(height: 10),

SwitchListTile(
value: furnished,
title: const Text("Furnished"),
onChanged: (value) {
setDialogState(() {
furnished = value;
});
},
),

SwitchListTile(
value: parking,
title: const Text("Parking"),
onChanged: (value) {
setDialogState(() {
parking = value;
});
},
),
],
),
),
actions: [
TextButton(
child: const Text("Cancel"),
onPressed: () {
Navigator.pop(context);
},
),
ElevatedButton(
child: const Text("Save"),
onPressed: () async {
final unit = Unit(
id: const Uuid().v4(),
buildingId: widget.building.id,
unitNumber: unitController.text.trim(),
type: unitType,
bedrooms:
int.tryParse(bedroomController.text) ?? 1,
bathrooms:
int.tryParse(bathroomController.text) ?? 1,
rent:
double.tryParse(rentController.text) ?? 0,
deposit:
double.tryParse(depositController.text) ?? 0,
occupied: false,
tenantId: "",
furnished: furnished,
parking: parking,
status: "Vacant",
images: const [],
);

await _service.addUnit(unit);

if (!mounted) return;

Navigator.pop(context);
},
),
],
);
},
);
},
);
}
@override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text(widget.building.name),
      centerTitle: true,
    ),
    floatingActionButton: FloatingActionButton.extended(
      icon: const Icon(Icons.add),
      label: const Text("Add Unit"),
      onPressed: _showAddUnitDialog,
    ),
    body: StreamBuilder<List<Unit>>(
      stream: _service.getUnits(widget.building.id),
      builder: (context, snapshot) {
        if (snapshot.connectionState ==
            ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }

        if (snapshot.hasError) {
          return Center(
            child: Text(
              "Error: ${snapshot.error}",
            ),
          );
        }

        final units = snapshot.data ?? [];

        if (units.isEmpty) {
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.meeting_room_outlined,
                  size: 90,
                  color: Colors.grey,
                ),
                SizedBox(height: 20),
                Text(
                  "No units yet",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  "Tap 'Add Unit' to create your first unit.",
                ),
              ],
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: units.length,
          itemBuilder: (context, index) {
            final unit = units[index];

            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [

                    Row(
                      children: [

                        CircleAvatar(
                          radius: 26,
                          backgroundColor:
                          unit.occupied
                              ? Colors.red.shade100
                              : Colors.green.shade100,
                          child: Icon(
                            Icons.home,
                            color: unit.occupied
                                ? Colors.red
                                : Colors.green,
                          ),
                        ),

                        const SizedBox(width: 15),

                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [

                              Text(
                                "Unit ${unit.unitNumber}",
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                              Text(unit.type),
                            ],
                          ),
                        ),

                        Chip(
                          label: Text(unit.status),
                          backgroundColor:
                          unit.occupied
                              ? Colors.red.shade100
                              : Colors.green.shade100,
                        ),
                      ],
                    ),

                    const Divider(height: 30),

                    Row(
                      mainAxisAlignment:
                      MainAxisAlignment.spaceBetween,
                      children: [

                        Text(
                          "Bedrooms: ${unit.bedrooms}",
                        ),

                        Text(
                          "Bathrooms: ${unit.bathrooms}",
                        ),
                      ],
                    ),

                    const SizedBox(height: 10),

                    Row(
                      mainAxisAlignment:
                      MainAxisAlignment.spaceBetween,
                      children: [

                        Text(
                          "Rent: KES ${unit.rent.toStringAsFixed(0)}",
                        ),

                        Text(
                          "Deposit: KES ${unit.deposit.toStringAsFixed(0)}",
                        ),
                      ],
                    ),

                    const SizedBox(height: 10),

                    Row(
                      children: [

                        Icon(
                          unit.parking
                              ? Icons.local_parking
                              : Icons.not_interested,
                          size: 18,
                        ),

                        const SizedBox(width: 5),

                        Text(
                          unit.parking
                              ? "Parking"
                              : "No Parking",
                        ),

                        const SizedBox(width: 20),

                        Icon(
                          unit.furnished
                              ? Icons.chair
                              : Icons.chair_outlined,
                          size: 18,
                        ),

                        const SizedBox(width: 5),

                        Text(
                          unit.furnished
                              ? "Furnished"
                              : "Unfurnished",
                        ),
                      ],
                    ),

                    const SizedBox(height: 20),

                    Row(
                      children: [

                        Expanded(
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.edit),
                            label: const Text("Edit"),
                            onPressed: () {
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    "Edit feature coming next",
                                  ),
                                ),
                              );
                            },
                          ),
                        ),

                        const SizedBox(width: 10),

                        Expanded(
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red,
                            ),
                            icon: const Icon(Icons.delete),
                            label: const Text("Delete"),
                            onPressed: () async {
                              final confirm =
                              await showDialog<bool>(
                                context: context,
                                builder: (_) => AlertDialog(
                                  title: const Text(
                                    "Delete Unit",
                                  ),
                                  content: const Text(
                                    "Are you sure you want to delete this unit?",
                                  ),
                                  actions: [

                                    TextButton(
                                      onPressed: () {
                                        Navigator.pop(
                                          context,
                                          false,
                                        );
                                      },
                                      child: const Text(
                                        "Cancel",
                                      ),
                                    ),

                                    ElevatedButton(
                                      onPressed: () {
                                        Navigator.pop(
                                          context,
                                          true,
                                        );
                                      },
                                      child: const Text(
                                        "Delete",
                                      ),
                                    ),
                                  ],
                                ),
                              );

                              if (confirm == true) {
                                await _service.deleteUnit(
                                  unit.id,
                                );
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    ),
  );
}
}