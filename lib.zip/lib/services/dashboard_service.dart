import '../models/dashboard.dart';
import '../models/dashboard_activity.dart';

import 'building_service.dart';
import 'maintenance_service.dart';
import 'payment_service.dart';
import 'tenant_service.dart';
import 'unit_service.dart';

class DashboardService {
  DashboardService();

  final BuildingService _buildingService = BuildingService();
  final UnitService _unitService = UnitService();
  final TenantService _tenantService = TenantService();
  final PaymentService _paymentService = PaymentService();
  final MaintenanceService _maintenanceService =
  MaintenanceService();

  Future<Dashboard> loadDashboard() async {
    final totalBuildings =
    await _buildingService.totalBuildings();

    final totalUnits =
    await _unitService.getTotalUnits();

    final occupiedUnits =
    await _unitService.getOccupiedCount();

    final vacantUnits =
    await _unitService.getVacantCount();

    final occupancyRate =
    await _unitService.getOccupancyRate();

    final totalRevenue =
    await _paymentService.getTotalRevenue();

    final expectedRevenue =
    await _unitService.getMonthlyRevenue();

    final monthlyRevenue =
    await _paymentService.getMonthlyRevenue();

    final tenants =
    await _tenantService.getTenants().first;

    final openMaintenance =
    await _maintenanceService.getOpenRequestCount();

    final collectionRate =
    expectedRevenue > 0
        ? (totalRevenue / expectedRevenue) * 100
        : 0.0;

    return Dashboard(
      totalBuildings: totalBuildings,
      totalUnits: totalUnits,
      occupiedUnits: occupiedUnits,
      vacantUnits: vacantUnits,
      totalTenants: tenants.length,
      occupancyRate: occupancyRate,
      totalRevenue: totalRevenue,
      expectedRevenue: expectedRevenue,
      collectionRate: collectionRate,
      openMaintenance: openMaintenance,
      monthlyRevenue: monthlyRevenue,
    );
  }

  Future<List<DashboardActivity>> loadRecentActivity() async {
    final tenants =
    await _tenantService.getTenants().first;

    final activities = <DashboardActivity>[];

    for (final tenant in tenants.take(5)) {
      activities.add(
        DashboardActivity(
          title: 'New Tenant',
          subtitle: tenant.name,
          timestamp: DateTime.now(),
          type: DashboardActivityType.tenant,
        ),
      );
    }

    return activities;
  }
}