import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/unit.dart';

class UnitService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<Unit>> getUnits(String buildingId) {
    return _firestore
        .collection('units')
        .where('buildingId', isEqualTo: buildingId)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => Unit.fromMap(doc.id, doc.data()))
          .toList();
    });
  }

  Future<void> addUnit(Unit unit) async {
    await _firestore
        .collection('units')
        .doc(unit.id)
        .set(unit.toMap());
  }

  Future<void> updateUnit(Unit unit) async {
    await _firestore
        .collection('units')
        .doc(unit.id)
        .update(unit.toMap());
  }

  Future<void> deleteUnit(String id) async {
    await _firestore
        .collection('units')
        .doc(id)
        .delete();
  }
}