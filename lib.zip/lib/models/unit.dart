class Unit {
  final String id;

  final String buildingId;

  final String unitNumber;

  final String type;

  final int bedrooms;

  final int bathrooms;

  final double rent;

  final double deposit;

  final bool occupied;

  final String tenantId;

  Unit({
    required this.id,
    required this.buildingId,
    required this.unitNumber,
    required this.type,
    required this.bedrooms,
    required this.bathrooms,
    required this.rent,
    required this.deposit,
    required this.occupied,
    required this.tenantId,
  });

  factory Unit.fromMap(
      String id,
      Map<String, dynamic> map,
      ) {
    return Unit(
      id: id,
      buildingId: map['buildingId'] ?? '',
      unitNumber: map['unitNumber'] ?? '',
      type: map['type'] ?? '',
      bedrooms: map['bedrooms'] ?? 1,
      bathrooms: map['bathrooms'] ?? 1,
      rent: (map['rent'] ?? 0).toDouble(),
      deposit: (map['deposit'] ?? 0).toDouble(),
      occupied: map['occupied'] ?? false,
      tenantId: map['tenantId'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'buildingId': buildingId,
      'unitNumber': unitNumber,
      'type': type,
      'bedrooms': bedrooms,
      'bathrooms': bathrooms,
      'rent': rent,
      'deposit': deposit,
      'occupied': occupied,
      'tenantId': tenantId,
    };
  }
}